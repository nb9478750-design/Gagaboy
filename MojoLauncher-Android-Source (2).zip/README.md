# MojoLauncher - Android Minecraft Java Launcher

MojoLauncher is a high-performance Android launcher for Minecraft Java Edition built with Kotlin, JNI, and isolated instance management.

## Features
- **Isolated Game Instances**: Separate `.minecraft/instances/<id>` folders for clean profiles.
- **Mod Loader Integration**: Support for Fabric, Forge, NeoForge, and Quilt installers.
- **Modpack Importer**: Direct `.mrpack` (Modrinth) and CurseForge `.zip` archive importer.
- **Custom Touch Controls**: Drag & drop custom buttons, D-pad, and key remapping.
- **Java Runtimes**: Support for Java 8, Java 17, and Java 21 runtime environments.

## Building Debug APK
Run the following Gradle command from the root `/android` directory:

```bash
./gradlew assembleDebug
```

The output debug APK will be created at:
`app/build/outputs/apk/debug/app-debug.apk`
