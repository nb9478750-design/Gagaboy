package com.mojolauncher.app

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // MojoLauncher Android Native Entrypoint
        // Handles Java Process execution via JNI, LWJGL bridge, and custom touch overlays
    }
}
